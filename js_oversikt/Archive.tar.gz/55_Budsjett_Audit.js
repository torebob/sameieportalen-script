// =============================================================================
// Budsjettmal – Validator (kollisjonsfri)
// FILE: 55_Budsjett_Audit.gs
// VERSION: 1.0.1
// UPDATED: 2025-09-15
// NOTE: Ingen globale const-er; bruker globalThis.BUDGET.AUDIT.*
// =============================================================================

// Namespace + standardverdier (idempotent)
(function (glob) {
  var B = glob.BUDGET || {};
  var monthsFromSchema = [];
  try { monthsFromSchema = (typeof getBudgetSchema === 'function' && getBudgetSchema().months) || []; } catch (e) {}
  var months = monthsFromSchema.length ? monthsFromSchema : ['Jan','Feb','Mar','Apr','Mai','Jun','Jul','Aug','Sep','Okt','Nov','Des'];

  var aliases = {
    '1':'Jan','01':'Jan','jan':'Jan','januar':'Jan',
    '2':'Feb','02':'Feb','feb':'Feb','februar':'Feb',
    '3':'Mar','03':'Mar','mar':'Mar','mars':'Mar',
    '4':'Apr','04':'Apr','apr':'Apr','april':'Apr',
    '5':'Mai','05':'Mai','mai':'Mai',
    '6':'Jun','06':'Jun','jun':'Jun','juni':'Jun',
    '7':'Jul','07':'Jul','jul':'Jul','juli':'Jul',
    '8':'Aug','08':'Aug','aug':'Aug','august':'Aug',
    '9':'Sep','09':'Sep','sep':'Sep','september':'Sep',
    '10':'Okt','okt':'Okt','oktober':'Okt',
    '11':'Nov','nov':'Nov','november':'Nov',
    '12':'Des','des':'Des','desember':'Des'
  };

  var cols = {
    year: ['år','budsjettår','year'],
    version: ['versjon','version'],
    account: ['konto','kontonr','konto nr','account'],
    name: ['navn','tekst','tittel','beskrivelse','name'],
    costCenter: ['kostnadssted','ansvar','enhet','avdeling','costcenter'],
    project: ['prosjekt','anlegg','project'],
    vat: ['mva','mva_kode','mvakode','vat','mva kode'],
    type: ['type','art','kategori','category'],
    annual: ['årsbeløp','år','beløp år','annual'],
    month: ['måned','mnd','month'],
    amount: ['beløp','amount','sum'],
    active: ['aktiv','active','status'],
    comment: ['kommentar','notat','comment']
  };

  B.AUDIT = Object.assign({}, B.AUDIT || {}, {
    MONTHS: months,
    MONTH_ALIASES: aliases,
    COLUMNS: cols,
    REPORT_SHEET: (B.AUDIT && B.AUDIT.REPORT_SHEET) || 'BUDSJETT_VALIDERING',
    VERSION: '1.0.1',
    UPDATED: '2025-09-15'
  });

  glob.BUDGET = B;
})(globalThis);

// --------------------------------- API ---------------------------------------

function auditBudgetTemplate(sheetName) {
  var ss = SpreadsheetApp.getActive();
  var sh = ss.getSheetByName(sheetName);
  if (!sh) return { ok:false, errors:['Fant ikke ark: ' + sheetName] };

  var values = sh.getDataRange().getValues();
  if (!values || values.length < 2) return { ok:false, errors:['Ingen data i ark: ' + sheetName] };

  var header = values[0].map(function(h){ return String(h || '').trim(); });
  var col = budgetAuditMapColumns_(header, globalThis.BUDGET.AUDIT.COLUMNS);
  var monthCols = budgetAuditDetectMonthColumns_(header);
  var isLong = !!(col.month && col.amount);
  var isWide = Object.keys(monthCols).length > 0;

  var errors = [];
  var warnings = [];

  if (!col.year) errors.push('Mangler kolonne for År.');
  if (!col.account) errors.push('Mangler kolonne for Konto.');
  if (!isLong && !isWide) errors.push('Fant verken lang form (Måned+Beløp) eller bred form (Jan–Des).');

  var sample = values.slice(1, Math.min(values.length, 51));
  var numericCells = 0, nonNumericCells = 0, monthRowsMissing = 0;

  if (isLong) {
    var mCol = col.month - 1, aCol = col.amount - 1;
    for (var i=0;i<sample.length;i++) {
      var r = sample[i];
      var v = budgetAuditToNumber_(r[aCol]);
      if (isFinite(v) && v !== 0) numericCells++; else nonNumericCells++;
    }
  } else if (isWide) {
    for (var j=0;j<sample.length;j++) {
      var r2 = sample[j];
      var any = false;
      for (var m in monthCols) {
        var idx = monthCols[m] - 1;
        var v2 = budgetAuditToNumber_(r2[idx]);
        if (isFinite(v2) && v2 !== 0) { any = true; numericCells++; }
      }
      if (!any) monthRowsMissing++;
    }
  }

  var repName = globalThis.BUDGET.AUDIT.REPORT_SHEET;
  var rep = ss.getSheetByName(repName) || ss.insertSheet(repName);
  rep.clear();
  rep.getRange(1,1,1,2).setValues([['Felt','Verdi']]).setFontWeight('bold');

  var rows = [
    ['Ark', sheetName],
    ['Format', isLong ? 'long' : (isWide ? 'wide' : 'unknown')],
    ['OK', errors.length ? 'NEI' : 'JA'],
    ['Feil (antall)', String(errors.length)],
    ['Advarsler (antall)', String(warnings.length)],
    ['Stikkprøver (rader)', String(sample.length)],
    ['Med tall (celler)', String(numericCells)],
    ['Uten tall (celler)', String(nonNumericCells)],
    ['Bredt: rader uten månedsbeløp', String(monthRowsMissing)]
  ];
  rep.getRange(2,1,rows.length,2).setValues(rows);

  var r0 = rows.length + 3;
  if (errors.length) {
    rep.getRange(r0,1,1,1).setValue('FEIL').setFontWeight('bold'); r0++;
    rep.getRange(r0,1,errors.length,1).setValues(errors.map(function(e){ return [e]; })); r0 += errors.length + 1;
  }
  if (warnings.length) {
    rep.getRange(r0,1,1,1).setValue('ADVARSLER').setFontWeight('bold'); r0++;
    rep.getRange(r0,1,warnings.length,1).setValues(warnings.map(function(w){ return [w]; })); r0 += warnings.length + 1;
  }

  rep.autoResizeColumns(1, 6);
  return { ok: errors.length === 0, errors: errors, warnings: warnings, mappedColumns: col, monthColumns: monthCols };
}

// ------------------------------- Helpers -------------------------------------

function budgetAuditMapColumns_(header, defs) {
  var lower = header.map(function(h){ return String(h||'').trim().toLowerCase(); });
  var out = {};
  Object.keys(defs).forEach(function(key){
    var aliases = defs[key];
    var idx = 0;
    for (var i=0;i<aliases.length;i++){
      var a = String(aliases[i]).toLowerCase();
      var p = lower.indexOf(a);
      if (p >= 0) { idx = p+1; break; }
    }
    out[key] = idx;
  });
  return out;
}

function budgetAuditDetectMonthColumns_(header) {
  var map = {};
  var AL = globalThis.BUDGET.AUDIT.MONTH_ALIASES;
  var MONTHS = globalThis.BUDGET.AUDIT.MONTHS;

  for (var i=0;i<header.length;i++){
    var raw = String(header[i]||'').trim().toLowerCase();
    var norm = AL[raw] || AL[raw.replace(/\.$/, '')] || null;
    if (norm && MONTHS.indexOf(norm) >= 0) {
      map[norm] = i+1;
    } else {
      var direct = {jan:'Jan',feb:'Feb',mar:'Mar',apr:'Apr',mai:'Mai',jun:'Jun',jul:'Jul',aug:'Aug',sep:'Sep',okt:'Okt',nov:'Nov',des:'Des'}[raw];
      if (direct) map[direct] = i+1;
    }
  }
  return map;
}

function budgetAuditToNumber_(v) {
  if (v === '' || v == null) return NaN;
 return Sameie.Num.parseNordicNumber(v);
  n;
}
