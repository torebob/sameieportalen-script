// Ett globalt namespace for å unngå kollisjoner i Apps Script
var Sameie = typeof Sameie === 'object' ? Sameie : {};
